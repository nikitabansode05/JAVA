package com.transflower.statuscodeplayground;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatuscodeplaygroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
