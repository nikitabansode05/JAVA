package com.transflower.statuscodeplayground.stepdefs;

import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class CucumberTestRunner {
}