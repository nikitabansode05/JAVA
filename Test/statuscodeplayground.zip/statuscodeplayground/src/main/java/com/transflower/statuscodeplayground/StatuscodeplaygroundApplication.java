package com.transflower.statuscodeplayground;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatuscodeplaygroundApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatuscodeplaygroundApplication.class, args);
	}

}
