package com.tap.testing.AssessmentAPITesting.AuthenticationTestData;

public class Role {
    private int id;
    private String name;
    private String lob;

    public Role(){
        id=0;
        name=null;
        lob=null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }


}
